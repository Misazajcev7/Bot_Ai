# HellNotary

A client-side Fabric mod for Minecraft 26.2. Press **F9** while a book is
open to send its raw text to a local Ollama instance (`qwen2.5:1.5b`) for a
formal "verdict" against the VanillaSquad server rules; the response is
copied to your clipboard. Press **F10** while editing a writable book to
insert the last verdict directly into the current page (splitting across
multiple pages automatically if it's too long for one).

## Before you build

Minecraft went **unobfuscated with official Mojang names built-in as of
26.1**, and Fabric dropped official Yarn support at the same time. That's a
bigger-than-usual change to the toolchain, and it landed after my training
data — I've written this against what the Fabric docs describe for that
migration, but you should expect to spend real time reconciling it against
your actual dev environment. Concretely:

1. **`gradle.properties` version pins** (`loader_version`, `fabric_version`,
   Loom version in `build.gradle`) — I could not confirm exact current
   numbers. Get them from https://fabricmc.net/develop/ for MC 26.2.
2. **`mappings` block in `build.gradle`** — commented out. Try building
   without it first (since 26.2 is unobfuscated); uncomment
   `loom.officialMojangMappings()` only if Loom complains.
3. **Fabric API package for `KeyBindingHelper`** — moved from
   `...client.keybinding.v1` to `...client.keymapping.v1` per the 26.1
   rename pass. Confirm this is still current for 26.2.
4. **Every field/method name in the `mixin/client/` accessor interfaces**
   (`BookEditScreenAccessor`, `BookViewScreenAccessor`, `BookPagesAccessor`)
   — these are my best guess based on the pre-26.x layout
   (`book`, `pages`, `currentPage`, `bookAccess`). Since Mojang mappings
   don't rename things as often as Yarn did, they're plausible, but
   **open the decompiled `BookEditScreen`/`BookViewScreen` classes in your
   IDE and confirm** before relying on them. This is the single riskiest
   part of the mod.
5. **`PAGE_CHAR_LIMIT` / `MAX_PAGES`** in `BookEditScreenMixin` — sanity
   check against current vanilla constants.
6. After mutating the `pages` list directly in the mixin, you may need to
   call whatever internal method vanilla uses to refresh the on-screen page
   widget — noted inline where relevant.

## Requirements

- A local Ollama install running `qwen2.5:1.5b`, reachable at
  `http://localhost:11434`.
- Java 21+ (required by MC 26.x).

## Project layout

```
src/main/java/com/hellnotary/HellNotaryMod.java          common entrypoint (logging only)
src/client/java/com/hellnotary/client/
  HellNotaryClient.java        client entrypoint, tick handling
  HellNotaryKeybinds.java      F9 / F10 keybindings
  OllamaClient.java            async HTTP call + hardcoded system prompt
  BookTextExtractor.java       pulls raw text out of a book ItemStack
  VerdictState.java            holds the latest verdict for the paste key
src/client/java/com/hellnotary/mixin/client/
  BookEditScreenAccessor.java  exposes private `book`/`currentPage` fields
  BookViewScreenAccessor.java  exposes private book-access field (viewer)
  BookPagesAccessor.java       exposes the mutable in-progress pages list
  BookEditScreenMixin.java     handles the F10 paste-and-split behavior
```
