package com.hellnotary;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Common entrypoint. This mod is entirely client-side (it reads a locally
 * opened book screen and talks to a local Ollama instance), so there's
 * nothing to do on the server/common side beyond logging.
 */
public class HellNotaryMod implements ModInitializer {

	public static final String MOD_ID = "hellnotary";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	@Override
	public void onInitialize() {
		LOGGER.info("HellNotary loaded (client-only functionality).");
	}
}
