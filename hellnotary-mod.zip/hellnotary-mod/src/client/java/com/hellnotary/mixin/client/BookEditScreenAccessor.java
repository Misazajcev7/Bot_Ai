package com.hellnotary.mixin.client;

import net.minecraft.client.gui.screens.inventory.BookEditScreen;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/**
 * VERIFY the field name below against your actual 26.2 dev environment
 * sources (right-click BookEditScreen -> "Decompile" in your IDE, or check
 * mappings.dev). At the time this was written the writable-book ItemStack
 * field on BookEditScreen was commonly named `book`; recent versions may
 * differ.
 */
@Mixin(BookEditScreen.class)
public interface BookEditScreenAccessor {

	@Accessor("book")
	ItemStack hellnotary$getBook();

	/** Currently displayed page index — needed by the paste mixin below. */
	@Accessor("currentPage")
	int hellnotary$getCurrentPage();
}
