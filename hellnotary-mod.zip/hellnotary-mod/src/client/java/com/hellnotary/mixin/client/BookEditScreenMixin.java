package com.hellnotary.mixin.client;

import com.hellnotary.client.HellNotaryKeybinds;
import com.hellnotary.client.VerdictState;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.gui.screens.inventory.BookEditScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.ArrayList;
import java.util.List;

/**
 * Intercepts key presses on the book editor so the dedicated "paste verdict"
 * key (default F10, see HellNotaryKeybinds) inserts the last AI verdict
 * directly into the page(s) being edited — including splitting it across
 * multiple pages if it's longer than a single page's character limit,
 * which is the actual "layout limitation" worth bypassing here (vanilla
 * requires the player to do this split manually).
 *
 * VERIFY: exact per-page character limit for 26.2 — historically this was a
 * constant somewhere around BookEditScreen or Item (e.g. a literal 1024, or
 * a named constant like BookEditScreen.MAX_PAGE_LENGTH). Adjust PAGE_CHAR_LIMIT
 * below to match, and adjust the max-pages constant similarly.
 */
@Mixin(BookEditScreen.class)
public abstract class BookEditScreenMixin {

	private static final int PAGE_CHAR_LIMIT = 1024; // VERIFY against actual vanilla constant
	private static final int MAX_PAGES = 100; // VERIFY against actual vanilla constant

	/**
	 * Fires before vanilla's own keyPressed logic. If it's our paste key,
	 * we handle it ourselves and cancel further processing (return true so
	 * the screen treats the key event as consumed).
	 */
	@Inject(method = "keyPressed", at = @At("HEAD"), cancellable = true)
	private void hellnotary$onKeyPressed(int keyCode, int scanCode, int modifiers, CallbackInfoReturnable<Boolean> cir) {
		if (!matchesPasteVerdictKey(keyCode)) {
			return;
		}

		String verdict = VerdictState.getLastVerdict();
		if (verdict == null || verdict.isBlank()) {
			return; // nothing to paste; let vanilla handle the keystroke normally
		}

		insertVerdictIntoPages((BookEditScreen) (Object) this, verdict);
		cir.setReturnValue(true);
	}

	private boolean matchesPasteVerdictKey(int keyCode) {
		InputConstants.Key boundKey = HellNotaryKeybinds.PASTE_VERDICT.key;
		return boundKey != null && boundKey.getValue() == keyCode && boundKey.getType() == InputConstants.Type.KEYSYM;
	}

	private void insertVerdictIntoPages(BookEditScreen screen, String verdict) {
		List<String> pages = ((BookPagesAccessor) screen).hellnotary$getPages();
		int currentPage = ((BookEditScreenAccessor) screen).hellnotary$getCurrentPage();

		List<String> chunks = splitIntoPages(verdict, PAGE_CHAR_LIMIT);

		if (pages.isEmpty()) {
			pages.add("");
		}
		if (currentPage < 0 || currentPage >= pages.size()) {
			currentPage = 0;
		}

		// Replace the current page with the first chunk, then insert any
		// remaining chunks as new pages immediately after it (capped at MAX_PAGES).
		pages.set(currentPage, chunks.get(0));
		for (int i = 1; i < chunks.size() && pages.size() < MAX_PAGES; i++) {
			pages.add(currentPage + i, chunks.get(i));
		}

		// VERIFY: after mutating the pages list directly, vanilla's rendered
		// EditBox/page-selector widgets likely need to be refreshed to pick up
		// the change — e.g. by re-invoking whatever internal method the
		// existing "next/previous page" buttons call. If nothing updates
		// visually, add an @Invoker here for that method and call it.
	}

	private List<String> splitIntoPages(String text, int limit) {
		List<String> result = new ArrayList<>();
		int i = 0;
		while (i < text.length()) {
			int end = Math.min(i + limit, text.length());
			// avoid splitting mid-word where possible
			if (end < text.length()) {
				int lastSpace = text.lastIndexOf(' ', end);
				if (lastSpace > i) {
					end = lastSpace;
				}
			}
			result.add(text.substring(i, end).strip());
			i = end;
		}
		if (result.isEmpty()) {
			result.add("");
		}
		return result;
	}
}
