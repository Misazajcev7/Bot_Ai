package com.hellnotary.mixin.client;

import net.minecraft.client.gui.screens.inventory.BookEditScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.List;

/**
 * VERIFY field name: the in-progress, not-yet-saved page contents of an open
 * writable book have historically been kept as a mutable List<String> on
 * BookEditScreen (commonly named `pages`). If 26.2 restructured page state
 * behind a dedicated helper object (increasingly likely given ongoing GUI
 * refactors), you'll need to retarget this accessor at that object instead.
 */
@Mixin(BookEditScreen.class)
public interface BookPagesAccessor {

	@Accessor("pages")
	List<String> hellnotary$getPages();
}
