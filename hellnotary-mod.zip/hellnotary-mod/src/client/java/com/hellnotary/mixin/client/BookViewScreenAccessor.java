package com.hellnotary.mixin.client;

import net.minecraft.client.gui.screens.inventory.BookViewScreen;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/** VERIFY field name — see note in BookEditScreenAccessor. */
@Mixin(BookViewScreen.class)
public interface BookViewScreenAccessor {

	@Accessor("bookAccess")
	Object hellnotary$getBookAccess();

	// BookViewScreen historically wraps the stack in a small "BookAccess"
	// interface rather than holding an ItemStack directly. If that's still
	// true in 26.2, replace the above with a targeted accessor/invoker that
	// pulls the ItemStack out of that wrapper, e.g. a WrittenBookAccess impl.
	default ItemStack hellnotary$getBook() {
		Object access = hellnotary$getBookAccess();
		if (access instanceof BookViewScreen.WrittenBookAccess wba) {
			return wba.book();
		}
		return null;
	}
}
