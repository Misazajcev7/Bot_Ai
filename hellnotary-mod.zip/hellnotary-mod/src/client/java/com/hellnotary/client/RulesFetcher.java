package com.hellnotary.client;

import com.hellnotary.HellNotaryMod;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.concurrent.CompletableFuture;

/**
 * Fetches the current server rules text from a remote raw-text URL at
 * request time, rather than hardcoding it in the mod.
 *
 * Currently points at a GitHub Gist raw URL, which serves plain UTF-8 text
 * directly (no HTML wrapper, unlike a normal gist/pastebin viewer page) —
 * verified working as of this writing.
 */
public final class RulesFetcher {

	private static final String RULES_URL = "https://gist.githubusercontent.com/Misazajcev7/7498ac7af980aad17e6434883c4745a6/raw/92bffdcf938478d74c929f7312952043e17bef45/gistfile1.txt";
	// NOTE: this is pinned to a specific gist revision (the hash after /raw/).
	// That means it will always return exactly this text, even if the gist is
	// edited later — if you want future rule edits to take effect automatically,
	// use the unpinned form instead: .../Misazajcev7/7498ac7af980aad17e6434883c4745a6/raw/gistfile1.txt
	// (GitHub redirects that to whatever the latest revision is at request time).

	private static final HttpClient HTTP_CLIENT = HttpClient.newBuilder()
			.connectTimeout(Duration.ofSeconds(5))
			.build();

	private RulesFetcher() {
	}

	public static CompletableFuture<String> fetchRules() {
		HttpRequest request = HttpRequest.newBuilder()
				.uri(URI.create(RULES_URL))
				.timeout(Duration.ofSeconds(15))
				.header("Accept-Charset", "UTF-8")
				.GET()
				.build();

		return HTTP_CLIENT.sendAsync(request, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8))
				.thenApply(response -> {
					if (response.statusCode() != 200) {
						throw new RuntimeException("Rules fetch returned HTTP " + response.statusCode() + " for " + RULES_URL);
					}
					return response.body();
				})
				.exceptionally(throwable -> {
					HellNotaryMod.LOGGER.error("Failed to fetch server rules from {}", RULES_URL, throwable);
					throw new RuntimeException(throwable);
				});
	}
}
