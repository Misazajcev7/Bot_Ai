package com.hellnotary.client;

import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Filterable;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.WritableBookContent;
import net.minecraft.world.item.component.WrittenBookContent;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Pulls the raw page text out of a book ItemStack's data components
 * (introduced in 1.20.5 and unchanged in shape through 26.2 as far as I can
 * verify from documentation — but if `WritableBookContent`/`WrittenBookContent`
 * were renamed or restructured in 26.x, this is the file to fix).
 *
 * Filterable<String>/Filterable<Component> hold a "raw" version and an
 * optionally-filtered (profanity-masked) version; we always want raw().
 */
public final class BookTextExtractor {

	private BookTextExtractor() {
	}

	/** Returns null if the stack isn't a writable or written book. */
	public static String extractRawText(ItemStack stack) {
		if (stack == null || stack.isEmpty()) {
			return null;
		}

		WritableBookContent writable = stack.get(DataComponents.WRITABLE_BOOK_CONTENT);
		if (writable != null) {
			List<Filterable<String>> pages = writable.pages();
			return joinRawStrings(pages);
		}

		WrittenBookContent written = stack.get(DataComponents.WRITTEN_BOOK_CONTENT);
		if (written != null) {
			List<Filterable<Component>> pages = written.pages();
			return pages.stream()
					.map(f -> f.raw().getString())
					.collect(Collectors.joining("\n\n"));
		}

		return null;
	}

	private static String joinRawStrings(List<Filterable<String>> pages) {
		return pages.stream()
				.map(Filterable::raw)
				.collect(Collectors.joining("\n\n"));
	}
}
