package com.hellnotary.client;

import java.util.concurrent.atomic.AtomicReference;

/** Holds the most recent verdict text so the paste-keybind can retrieve it. */
public final class VerdictState {

	public enum Status { IDLE, PENDING, READY, ERROR }

	private static final AtomicReference<String> LAST_VERDICT = new AtomicReference<>(null);
	private static volatile Status status = Status.IDLE;

	private VerdictState() {
	}

	public static void setPending() {
		status = Status.PENDING;
	}

	public static void setVerdict(String verdict) {
		LAST_VERDICT.set(verdict);
		status = Status.READY;
	}

	public static void setError() {
		status = Status.ERROR;
	}

	public static String getLastVerdict() {
		return LAST_VERDICT.get();
	}

	public static Status getStatus() {
		return status;
	}
}
