package com.hellnotary.client;

import com.hellnotary.HellNotaryMod;
import com.hellnotary.mixin.client.BookEditScreenAccessor;
import com.hellnotary.mixin.client.BookViewScreenAccessor;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.inventory.BookEditScreen;
import net.minecraft.client.gui.screens.inventory.BookViewScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;

public class HellNotaryClient implements ClientModInitializer {

	@Override
	public void onInitializeClient() {
		HellNotaryKeybinds.register();
		ClientTickEvents.END_CLIENT_TICK.register(this::onClientTick);
		HellNotaryMod.LOGGER.info("HellNotary client initialized.");
	}

	private void onClientTick(Minecraft client) {
		while (HellNotaryKeybinds.REQUEST_VERDICT.consumeClick()) {
			handleRequestVerdict(client);
		}
	}

	private void handleRequestVerdict(Minecraft client) {
		ItemStack book = resolveOpenBook(client);
		if (book == null) {
			feedback(client, "Книга не открыта.", ChatFormatting.RED);
			return;
		}

		String bookText = BookTextExtractor.extractRawText(book);
		if (bookText == null || bookText.isBlank()) {
			feedback(client, "Не удалось прочитать текст книги.", ChatFormatting.RED);
			return;
		}

		VerdictState.setPending();
		feedback(client, "HellNotary: загружаю правила и рассматриваю договор...", ChatFormatting.YELLOW);

		RulesFetcher.fetchRules()
				.thenCompose(rulesText -> OllamaClient.requestVerdict(
						rulesText,
						bookText,
						verdict -> client.execute(() -> {
							VerdictState.setVerdict(verdict);
							client.keyboardHandler.setClipboard(verdict);
							feedback(client, "Вердикт готов и скопирован в буфер обмена. Нажмите клавишу вставки в редакторе книги.", ChatFormatting.GREEN);
						}),
						error -> client.execute(() -> {
							VerdictState.setError();
							feedback(client, "Не удалось получить ответ от локальной модели.", ChatFormatting.RED);
						})
				))
				.exceptionally(throwable -> {
					client.execute(() -> {
						VerdictState.setError();
						feedback(client, "Не удалось загрузить правила сервера (проверьте ссылку Pastebin).", ChatFormatting.RED);
					});
					return null;
				});
	}

	/**
	 * Returns the ItemStack behind whichever book-related screen is currently
	 * open, or null if none is open.
	 *
	 * NAMING NOTE: the spec referenced `DataComponentTypes.WRITABLE_BOOK_CONTENT`
	 * / `WRITTEN_BOOK_CONTENT`, which is Yarn-style naming. Since 26.x uses
	 * official Mojang mappings (Yarn is deprecated), the equivalent official
	 * class is `net.minecraft.core.component.DataComponents` — that's what
	 * BookTextExtractor uses. If your dev environment resolves
	 * `DataComponentTypes` instead, your Loom setup is still on a Yarn-derived
	 * mapping set and this file should use that name instead.
	 *
	 * VERIFY: BookEditScreen/BookViewScreen's book-holding field names — see
	 * accessor mixins in mixin/client/.
	 */
	private ItemStack resolveOpenBook(Minecraft client) {
		if (client.screen instanceof BookEditScreen editScreen) {
			return ((BookEditScreenAccessor) editScreen).hellnotary$getBook();
		}
		if (client.screen instanceof BookViewScreen viewScreen) {
			return ((BookViewScreenAccessor) viewScreen).hellnotary$getBook();
		}
		return null;
	}

	private void feedback(Minecraft client, String message, ChatFormatting color) {
		if (client.player != null) {
			client.player.displayClientMessage(Component.literal("[HellNotary] " + message).withStyle(color), false);
		}
	}
}
