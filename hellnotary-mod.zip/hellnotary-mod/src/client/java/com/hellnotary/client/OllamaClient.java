package com.hellnotary.client;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.hellnotary.HellNotaryMod;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;

/**
 * Talks to a locally running Ollama instance (http://localhost:11434) to get
 * a "verdict" on a piece of book text, using rules fetched at runtime
 * (see RulesFetcher) rather than a hardcoded rule list.
 *
 * Rules, book text, and model output are all Russian/Cyrillic here, so every
 * layer that touches bytes on the wire is pinned to UTF-8 explicitly:
 * request body encoding, the Content-Type charset, and response decoding.
 */
public final class OllamaClient {

	private static final String ENDPOINT = "http://localhost:11434/api/generate";
	private static final String MODEL = "qwen2.5:1.5b";

	// Minimal harness around the fetched rules. Edit or drop this if you'd
	// rather the fetched Pastebin content BE the entire system prompt with
	// no wrapper at all.
	private static final String SYSTEM_PROMPT_TEMPLATE = """
			Ты — HellNotary, ИИ-ассистент по вопросам права сервера 'VanillaSquad'. \
			Твоя задача — сверить текст книги с правилами сервера, приведёнными ниже, \
			и вынести официальный вердикт: есть нарушение или сделка законна. Будь краток и формален. \
			Подпись в конце: 'Адская Канцелярия в курсе; наши волонтёры будут бороться за справедливость'.

			Правила сервера:
			%s
			""";

	private static final HttpClient HTTP_CLIENT = HttpClient.newBuilder()
			.connectTimeout(Duration.ofSeconds(5))
			.build();

	private OllamaClient() {
	}

	/**
	 * Sends the book text (plus the already-fetched rules) to Ollama
	 * asynchronously. Callback runs on an HttpClient background thread —
	 * hop back via MinecraftClient.execute(...) before touching game state.
	 */
	public static CompletableFuture<Void> requestVerdict(String rulesText, String bookText, Consumer<String> onSuccess, Consumer<Throwable> onError) {
		JsonObject payload = buildPayload(rulesText, bookText);
		String jsonBody = payload.toString();

		HttpRequest request = HttpRequest.newBuilder()
				.uri(URI.create(ENDPOINT))
				.timeout(Duration.ofSeconds(60))
				.header("Content-Type", "application/json; charset=UTF-8")
				.POST(HttpRequest.BodyPublishers.ofString(jsonBody, StandardCharsets.UTF_8))
				.build();

		return HTTP_CLIENT.sendAsync(request, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8))
				.thenAccept(response -> {
					if (response.statusCode() != 200) {
						onError.accept(new RuntimeException("Ollama returned HTTP " + response.statusCode() + ": " + response.body()));
						return;
					}
					try {
						JsonObject json = JsonParser.parseString(response.body()).getAsJsonObject();
						String verdict = json.has("response") ? json.get("response").getAsString() : "";
						onSuccess.accept(verdict.trim());
					} catch (Exception e) {
						onError.accept(e);
					}
				})
				.exceptionally(throwable -> {
					HellNotaryMod.LOGGER.error("Failed to reach local Ollama instance", throwable);
					onError.accept(throwable);
					return null;
				});
	}

	private static JsonObject buildPayload(String rulesText, String bookText) {
		String system = SYSTEM_PROMPT_TEMPLATE.formatted(rulesText);

		JsonObject payload = new JsonObject();
		payload.addProperty("model", MODEL);
		payload.addProperty("system", system);
		payload.addProperty("prompt", bookText);
		payload.addProperty("stream", false);
		// Gson serializes non-ASCII characters as \uXXXX escapes by default,
		// which is valid UTF-8-safe JSON either way (escapes decode fine on
		// Ollama's side) — no special handling needed here beyond the
		// explicit UTF_8 charset used when writing the request body above.
		return payload;
	}
}
