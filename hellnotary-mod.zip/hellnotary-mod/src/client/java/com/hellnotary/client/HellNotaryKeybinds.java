package com.hellnotary.client;

// VERIFY: the KeyBindingHelper package moved from
// net.fabricmc.fabric.api.client.keybinding.v1 -> ...client.keymapping.v1
// as part of the 26.1 Fabric API rename pass. Update the import below if your
// Fabric API version still uses the old package.
import net.fabricmc.fabric.api.client.keymapping.v1.KeyBindingHelper;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;

public final class HellNotaryKeybinds {

	public static final String CATEGORY = "key.categories.hellnotary";

	/** F9 while a book screen is open: extract text, send to Ollama. */
	public static KeyMapping REQUEST_VERDICT;

	/** Dedicated key (default F10) while the book editor is open: paste the last verdict into the current page. */
	public static KeyMapping PASTE_VERDICT;

	private HellNotaryKeybinds() {
	}

	public static void register() {
		REQUEST_VERDICT = KeyBindingHelper.registerKeyBinding(new KeyMapping(
				"key.hellnotary.request_verdict",
				InputConstants.Type.KEYSYM,
				InputConstants.KEY_F9,
				CATEGORY
		));

		PASTE_VERDICT = KeyBindingHelper.registerKeyBinding(new KeyMapping(
				"key.hellnotary.paste_verdict",
				InputConstants.Type.KEYSYM,
				InputConstants.KEY_F10,
				CATEGORY
		));
	}
}
