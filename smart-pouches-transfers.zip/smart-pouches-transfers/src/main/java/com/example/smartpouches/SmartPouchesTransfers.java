package com.example.smartpouches;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Common entrypoint. Smart Pouches & Transfers only manipulates client-side
 * GUI state and issues normal container clicks (the same packets a manual
 * shift-click or bundle interaction would send), so there is no dedicated
 * server-side logic to register here.
 */
public class SmartPouchesTransfers implements ModInitializer {
	public static final String MOD_ID = "smartpouches";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	@Override
	public void onInitialize() {
		LOGGER.info("Smart Pouches & Transfers initialized (common)");
	}
}
