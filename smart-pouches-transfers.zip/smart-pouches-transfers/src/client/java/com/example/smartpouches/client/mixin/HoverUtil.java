package com.example.smartpouches.client.mixin;

import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.world.inventory.Slot;

/**
 * Finds the slot under the given screen-space coordinates. Deliberately
 * reimplemented here (rather than reading vanilla's private "hoveredSlot"
 * field) using only the leftPos/topPos accessor and each Slot's own
 * x/y - both of which are far more stable, long-lived pieces of API than
 * any particular internal hover-tracking field.
 */
public final class HoverUtil {
	private static final int SLOT_SIZE = 16;

	private HoverUtil() {
	}

	public static Slot findHoveredSlot(AbstractContainerScreen<?> screen, double mouseX, double mouseY) {
		AbstractContainerScreenAccessor accessor = (AbstractContainerScreenAccessor) screen;
		int left = accessor.smartpouches$getLeftPos();
		int top = accessor.smartpouches$getTopPos();

		for (Slot slot : screen.getMenu().slots) {
			int sx = left + slot.x;
			int sy = top + slot.y;
			if (mouseX >= sx && mouseX < sx + SLOT_SIZE && mouseY >= sy && mouseY < sy + SLOT_SIZE) {
				return slot;
			}
		}
		return null;
	}
}
