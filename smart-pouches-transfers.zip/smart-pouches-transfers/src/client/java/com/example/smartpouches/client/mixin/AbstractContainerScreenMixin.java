package com.example.smartpouches.client.mixin;

import com.example.smartpouches.client.selection.MouseTracker;
import com.example.smartpouches.client.selection.SelectionManager;
import net.minecraft.client.gui.render.state.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.Slot;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Draws the BLUE (chest transfer) and GOLD (bundle transfer) markers over
 * marked slots, for every screen that extends AbstractContainerScreen (this
 * covers ChestScreen, InventoryScreen, ShulkerBoxScreen, generic container
 * screens, etc. automatically).
 *
 * VERIFY: this targets AbstractContainerScreen#extractRenderState, the
 * post-26.x replacement for the old render(GuiGraphics, ...) method,
 * confirmed against current Fabric docs for 26.2. The exact @At("TAIL")
 * injection point assumes the vanilla method's descriptor still matches
 * (GuiGraphicsExtractor, int, int, float) -> void; if genSources shows a
 * different signature (e.g. an additional parameter), update the
 * @Inject method signature to match.
 */
@Mixin(AbstractContainerScreen.class)
public abstract class AbstractContainerScreenMixin {

	@Unique
	private static final int MARKER_SIZE = 5;
	@Unique
	private static final int COLOR_CHEST_BLUE = 0xFF3B82F6;
	@Unique
	private static final int COLOR_BUNDLE_GOLD = 0xFFFFC800;
	@Unique
	private static final int COLOR_OUTLINE = 0xFF1A1A1A;

	@Inject(method = "extractRenderState", at = @At("TAIL"))
	private void smartpouches$drawMarkers(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta, CallbackInfo ci) {
		MouseTracker.update(mouseX, mouseY);

		AbstractContainerScreen<?> self = (AbstractContainerScreen<?>) (Object) this;
		AbstractContainerScreenAccessor accessor = (AbstractContainerScreenAccessor) self;
		int left = accessor.smartpouches$getLeftPos();
		int top = accessor.smartpouches$getTopPos();

		AbstractContainerMenu menu = self.getMenu();
		SelectionManager selection = SelectionManager.get();

		for (Slot slot : menu.slots) {
			boolean chest = selection.isMarked(menu, slot, SelectionManager.Marker.CHEST);
			boolean bundle = selection.isMarked(menu, slot, SelectionManager.Marker.BUNDLE);
			if (!chest && !bundle) continue;

			int slotScreenX = left + slot.x;
			int slotScreenY = top + slot.y;

			// Chest (blue) marker: top-left corner of the slot.
			if (chest) {
				smartpouches$drawDot(graphics, slotScreenX - 1, slotScreenY - 1, COLOR_CHEST_BLUE);
			}
			// Bundle (gold) marker: bottom-right corner of the slot, so both
			// can be visible on the same item at once.
			if (bundle) {
				smartpouches$drawDot(graphics, slotScreenX + 16 - MARKER_SIZE, slotScreenY + 16 - MARKER_SIZE, COLOR_BUNDLE_GOLD);
			}
		}
	}

	@Unique
	private void smartpouches$drawDot(GuiGraphicsExtractor graphics, int x, int y, int color) {
		graphics.fill(x, y, x + MARKER_SIZE, y + MARKER_SIZE, color);
		graphics.outline(x, y, MARKER_SIZE, MARKER_SIZE, COLOR_OUTLINE);
	}
}
