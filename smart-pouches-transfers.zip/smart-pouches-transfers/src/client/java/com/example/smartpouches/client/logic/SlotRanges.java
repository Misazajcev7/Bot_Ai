package com.example.smartpouches.client.logic;

import net.minecraft.world.inventory.AbstractContainerMenu;

import java.util.ArrayList;
import java.util.List;

/**
 * Vanilla container menus consistently lay out slots as:
 * [0 .. N-1]  = the block/container's own slots
 * [N .. N+35] = the player's 36 inventory slots (27 main + 9 hotbar)
 *
 * This ordering is what vanilla's own shift-click ("quick move") logic
 * relies on and has been stable for a very long time, so it's a safe
 * assumption to build on rather than hardcoding per-screen slot maps.
 * The plain player InventoryMenu has no "container" side (N = 0).
 */
public final class SlotRanges {
	private static final int PLAYER_INVENTORY_SIZE = 36;

	private SlotRanges() {
	}

	public static List<Integer> containerIndices(AbstractContainerMenu menu) {
		int containerCount = Math.max(0, menu.slots.size() - PLAYER_INVENTORY_SIZE);
		List<Integer> list = new ArrayList<>(containerCount);
		for (int i = 0; i < containerCount; i++) list.add(i);
		return list;
	}

	public static List<Integer> playerInventoryIndices(AbstractContainerMenu menu) {
		int containerCount = Math.max(0, menu.slots.size() - PLAYER_INVENTORY_SIZE);
		List<Integer> list = new ArrayList<>(PLAYER_INVENTORY_SIZE);
		for (int i = containerCount; i < menu.slots.size(); i++) list.add(i);
		return list;
	}
}
