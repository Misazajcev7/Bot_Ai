package com.example.smartpouches.client.mixin;

import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/**
 * Exposes AbstractContainerScreen's protected screen-space offset fields.
 * (AbstractContainerScreen already exposes its menu publicly via the
 * MenuAccess#getMenu() interface method, so only leftPos/topPos need an
 * accessor here.)
 *
 * VERIFY: field names "leftPos" / "topPos" have been stable under Mojang
 * mappings for many years and are unrelated to the 26.x rendering-state
 * rewrite, so they are very likely unchanged - but they were not
 * independently confirmed against 26.2 sources for this response. If Loom's
 * generated sources show different names, update the two @Accessor targets
 * below (nothing else needs to change).
 */
@Mixin(AbstractContainerScreen.class)
public interface AbstractContainerScreenAccessor {
	@Accessor("leftPos")
	int smartpouches$getLeftPos();

	@Accessor("topPos")
	int smartpouches$getTopPos();

	@Accessor("imageWidth")
	int smartpouches$getImageWidth();
}
