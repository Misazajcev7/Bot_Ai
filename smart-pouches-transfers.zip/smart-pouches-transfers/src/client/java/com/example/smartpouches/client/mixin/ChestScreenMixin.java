package com.example.smartpouches.client.mixin;

import com.example.smartpouches.client.gui.IconButton;
import com.example.smartpouches.client.logic.BundleLogic;
import com.example.smartpouches.client.logic.TransferLogic;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.screens.inventory.ChestScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.ChestMenu;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Adds the 4 requested buttons - [pack chest], [unpack chest], [transfer
 * up], [transfer down] - to the top-right of chest-style container screens.
 *
 * This mixin declares "extends AbstractContainerScreen<ChestMenu>" even
 * though it targets ChestScreen (a subclass). That's the standard Fabric
 * Mixin pattern for a subclass-targeting mixin that needs direct, typed
 * access to inherited members (getMenu(), addRenderableWidget(...)) via
 * plain `this.` calls instead of unchecked casts. The declared constructor
 * below is required by the Java compiler but is stripped/merged away by
 * Mixin at build time - it is never actually invoked.
 *
 * VERIFY: targets ChestScreen#init(); "init" has been the standard Screen
 * setup method name for a very long time and is unrelated to the rendering
 * rewrite, but the exact class ChestScreen<ChestMenu> was not
 * independently re-confirmed against 26.2 sources for this response.
 * This mixin only covers ChestScreen itself (single & double chests,
 * ender chests, and shulker boxes if they still share this class in 26.2).
 * If your target container uses a different/renamed screen class, mirror
 * this mixin for that class too.
 */
@Mixin(ChestScreen.class)
public abstract class ChestScreenMixin extends AbstractContainerScreen<ChestMenu> {

	private ChestScreenMixin(ChestMenu menu, Inventory playerInventory, Component title) {
		super(menu, playerInventory, title);
	}

	@Inject(method = "init", at = @At("TAIL"))
	private void smartpouches$addButtons(CallbackInfo ci) {
		AbstractContainerScreenAccessor accessor = (AbstractContainerScreenAccessor) this;
		int left = accessor.smartpouches$getLeftPos();
		int top = accessor.smartpouches$getTopPos();
		int imageWidth = accessor.smartpouches$getImageWidth();

		int size = 12;
		int spacing = 1;
		int startX = left + imageWidth - (size * 4 + spacing * 3) - 6;
		int y = top - size - 2;

		ChestMenu menu = this.getMenu();
		int containerId = menu.containerId;

		this.addRenderableWidget(new IconButton(startX, y, size, "\uD83E\uDDF3\u2191",
				Component.translatable("smartpouches.button.pack_chest"),
				btn -> BundleLogic.packContainer(menu, containerId)));

		this.addRenderableWidget(new IconButton(startX + (size + spacing), y, size, "\uD83E\uDDF3\u2193",
				Component.translatable("smartpouches.button.unpack_chest"),
				btn -> BundleLogic.unpackContainer(menu, containerId)));

		this.addRenderableWidget(new IconButton(startX + (size + spacing) * 2, y, size, "\u2191",
				Component.translatable("smartpouches.button.transfer_up"),
				btn -> TransferLogic.transferUp(menu, containerId)));

		this.addRenderableWidget(new IconButton(startX + (size + spacing) * 3, y, size, "\u2193",
				Component.translatable("smartpouches.button.transfer_down"),
				btn -> TransferLogic.transferDown(menu, containerId)));
	}
}
