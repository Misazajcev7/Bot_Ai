package com.example.smartpouches.client;

import com.example.smartpouches.SmartPouchesTransfers;
import com.example.smartpouches.client.mixin.HoverUtil;
import com.example.smartpouches.client.selection.MouseTracker;
import com.example.smartpouches.client.selection.SelectionManager;
import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenKeyboardEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.resources.Identifier;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.Slot;

/**
 * Registers the four keybinds from the spec and wires them up:
 *  - J:            select/deselect all (CHEST marker) in the open screen
 *  - K:            select/deselect all (BUNDLE marker) in the open screen
 *  - Middle click: toggle CHEST marker on the hovered slot
 *  - G:            toggle BUNDLE marker on the hovered slot
 *
 * Interaction is driven through Fabric API's ScreenEvents/ScreenKeyboardEvents
 * /ScreenMouseEvents rather than raw Mixins - these are a long-standing
 * Fabric API abstraction over screen input specifically meant to insulate
 * mod code from vanilla's internal event plumbing, so they're a safer bet
 * across a version jump like 26.2's than hand-rolled input mixins.
 *
 * VERIFY: the class names KeyMapping/KeyMappingHelper/KeyMapping.Category
 * and the GuiGraphicsExtractor-based render pipeline were confirmed
 * against current Fabric documentation for 26.2. Their exact Java package
 * paths (e.g. whether it's still
 * net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper) follow
 * Fabric's established module-naming convention but weren't independently
 * re-confirmed; if your IDE can't resolve an import below, search for the
 * class name in your dependencies view and fix the package.
 */
public class SmartPouchesTransfersClient implements ClientModInitializer {

	private static final KeyMapping.Category CATEGORY = KeyMapping.Category.register(
			Identifier.fromNamespaceAndPath(SmartPouchesTransfers.MOD_ID, "main"));

	private static final KeyMapping SELECT_ALL_CHEST = KeyMappingHelper.registerKeyMapping(new KeyMapping(
			"key.smartpouches.select_all_chest",
			InputConstants.Type.KEYSYM,
			InputConstants.KEY_J,
			CATEGORY));

	private static final KeyMapping SELECT_ALL_BUNDLE = KeyMappingHelper.registerKeyMapping(new KeyMapping(
			"key.smartpouches.select_all_bundle",
			InputConstants.Type.KEYSYM,
			InputConstants.KEY_K,
			CATEGORY));

	private static final KeyMapping TOGGLE_BUNDLE_MARKER = KeyMappingHelper.registerKeyMapping(new KeyMapping(
			"key.smartpouches.toggle_bundle_marker",
			InputConstants.Type.KEYSYM,
			InputConstants.KEY_G,
			CATEGORY));

	// GLFW_MOUSE_BUTTON_MIDDLE = 2. Used as a literal rather than a symbolic
	// constant since InputConstants may not expose a named middle-button
	// field (KeyMapping's mouse-type constructor just takes the raw code).
	private static final int MOUSE_BUTTON_MIDDLE = 2;

	private static final KeyMapping TOGGLE_CHEST_MARKER_MOUSE = KeyMappingHelper.registerKeyMapping(new KeyMapping(
			"key.smartpouches.toggle_chest_marker",
			InputConstants.Type.MOUSE,
			MOUSE_BUTTON_MIDDLE,
			CATEGORY));

	@Override
	public void onInitializeClient() {
		// Hook every container-style screen as it opens.
		ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
			if (!(screen instanceof AbstractContainerScreen<?> containerScreen)) return;

			ScreenKeyboardEvents.afterKeyPress(screen).register((scr, key, scancode, modifiers) -> {
				AbstractContainerMenu menu = containerScreen.getMenu();

				if (SELECT_ALL_CHEST.matches(key, scancode)) {
					SelectionManager.get().toggleAll(menu, menu.slots, SelectionManager.Marker.CHEST);
				} else if (SELECT_ALL_BUNDLE.matches(key, scancode)) {
					SelectionManager.get().toggleAll(menu, menu.slots, SelectionManager.Marker.BUNDLE);
				} else if (TOGGLE_BUNDLE_MARKER.matches(key, scancode)) {
					Slot hovered = HoverUtil.findHoveredSlot(containerScreen, MouseTracker.x(), MouseTracker.y());
					if (hovered != null && hovered.hasItem()) {
						SelectionManager.get().toggle(menu, hovered, SelectionManager.Marker.BUNDLE);
					}
				}
			});

			ScreenMouseEvents.allowMouseClick(screen).register((scr, mouseX, mouseY, button) -> {
				InputConstants.Key clicked = InputConstants.Type.MOUSE.getOrCreate(button);
				if (!clicked.equals(TOGGLE_CHEST_MARKER_MOUSE.getKey())) return true;

				Slot hovered = HoverUtil.findHoveredSlot(containerScreen, mouseX, mouseY);
				if (hovered != null && hovered.hasItem()) {
					SelectionManager.get().toggle(containerScreen.getMenu(), hovered, SelectionManager.Marker.CHEST);
				}
				return false; // consume the click so it doesn't also pick the item up
			});
		});

		SmartPouchesTransfers.LOGGER.info("Smart Pouches & Transfers initialized (client)");
	}
}
