package com.example.smartpouches.client.gui;

import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.client.gui.render.state.GuiGraphicsExtractor;
import net.minecraft.network.chat.Component;

import java.util.function.Consumer;

/**
 * A small square icon button used for the pack/unpack/transfer controls.
 * Deliberately simple (flat fill + glyph) instead of borrowing the vanilla
 * button texture, so it doesn't depend on any particular widgets atlas
 * layout that may have moved between versions.
 */
public class IconButton extends AbstractWidget {

	private final String glyph;
	private final Consumer<IconButton> onPress;

	public IconButton(int x, int y, int size, String glyph, Component tooltip, Consumer<IconButton> onPress) {
		super(x, y, size, size, Component.empty());
		this.glyph = glyph;
		this.onPress = onPress;
		this.setTooltip(net.minecraft.client.gui.components.Tooltip.create(tooltip));
	}

	@Override
	protected void extractWidgetRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
		int bg = isHovered() ? 0xFF5A5A5A : 0xFF373737;
		graphics.fill(getX(), getY(), getX() + width, getY() + height, bg);
		graphics.outline(getX(), getY(), width, height, 0xFF1A1A1A);

		// Center the glyph text within the button.
		int textWidth = net.minecraft.client.Minecraft.getInstance().font.width(glyph);
		int textX = getX() + (width - textWidth) / 2;
		int textY = getY() + (height - net.minecraft.client.Minecraft.getInstance().font.lineHeight) / 2;
		graphics.text(net.minecraft.client.Minecraft.getInstance().font, glyph, textX, textY, 0xFFFFFFFF, true);
	}

	@Override
	public boolean mouseClicked(double mouseX, double mouseY, int button) {
		if (button == 0 && isMouseOver(mouseX, mouseY)) {
			onPress.accept(this);
			return true;
		}
		return false;
	}

	@Override
	protected void updateWidgetNarration(NarrationElementOutput builder) {
		builder.add(net.minecraft.client.gui.narration.NarratedElementType.TITLE, Component.literal(glyph));
	}
}
