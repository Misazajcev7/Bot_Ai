package com.example.smartpouches.client.selection;

import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;

import java.util.HashSet;
import java.util.Set;
import java.util.WeakHashMap;

/**
 * Tracks the two marker sets (BLUE = "chest transfer", GOLD = "bundle
 * transfer") per open menu. Selection is stored by the menu's slot index
 * (Slot#index, i.e. the id AbstractContainerMenu assigns each slot), scoped
 * to the current AbstractContainerMenu instance. A new menu instance is
 * created every time a screen is (re)opened, so selections naturally reset
 * when the player closes the container - this matches "current screen" scope
 * from the spec.
 */
public final class SelectionManager {

	public enum Marker { CHEST, BUNDLE }

	private static final SelectionManager INSTANCE = new SelectionManager();

	public static SelectionManager get() {
		return INSTANCE;
	}

	private final WeakHashMap<AbstractContainerMenu, Set<Integer>> chestMarks = new WeakHashMap<>();
	private final WeakHashMap<AbstractContainerMenu, Set<Integer>> bundleMarks = new WeakHashMap<>();

	private SelectionManager() {
	}

	private Set<Integer> setFor(AbstractContainerMenu menu, Marker marker) {
		WeakHashMap<AbstractContainerMenu, Set<Integer>> map = marker == Marker.CHEST ? chestMarks : bundleMarks;
		return map.computeIfAbsent(menu, m -> new HashSet<>());
	}

	public boolean isMarked(AbstractContainerMenu menu, Slot slot, Marker marker) {
		return setFor(menu, marker).contains(slot.index);
	}

	/** Toggle a single slot's marker. Returns the new state (true = now marked). */
	public boolean toggle(AbstractContainerMenu menu, Slot slot, Marker marker) {
		Set<Integer> set = setFor(menu, marker);
		if (set.remove(slot.index)) {
			return false;
		}
		set.add(slot.index);
		return true;
	}

	public Set<Integer> getMarked(AbstractContainerMenu menu, Marker marker) {
		return setFor(menu, marker);
	}

	public void clear(AbstractContainerMenu menu, Marker marker) {
		setFor(menu, marker).clear();
	}

	/**
	 * "Select all / deselect all" toggle for the J and K keys.
	 * If anything is currently marked, this clears the marker set.
	 * Otherwise, it marks every eligible slot in the given slot range.
	 * Non-stackable items (max stack size 1 - tools, armor, etc.) are
	 * skipped, per spec.
	 */
	public void toggleAll(AbstractContainerMenu menu, Iterable<Slot> slots, Marker marker) {
		Set<Integer> set = setFor(menu, marker);
		if (!set.isEmpty()) {
			set.clear();
			return;
		}
		for (Slot slot : slots) {
			if (!slot.hasItem()) continue;
			ItemStack stack = slot.getItem();
			if (stack.getMaxStackSize() <= 1) continue; // skip non-stackable tools/armor
			set.add(slot.index);
		}
	}
}
