package com.example.smartpouches.client.logic;

import com.example.smartpouches.client.selection.SelectionManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.inventory.Slot;

import java.util.List;
import java.util.Set;

/**
 * Handles the [UP] / [DOWN] instant-transfer buttons.
 *
 * Rather than reimplementing vanilla's stack-merging/splitting rules by hand
 * (which is easy to get subtly wrong and desyncs from the server), this
 * simulates the same "quick move" (shift-click) action the player would
 * perform on each relevant slot. That keeps behaviour - stacking onto
 * partial stacks, respecting max stack size, container capacity, etc. -
 * identical to vanilla and correctly synced with the server, since
 * handleInventoryMouseClick both predicts locally and sends the real
 * ServerboundContainerClickPacket.
 *
 * VERIFY: MultiPlayerGameMode#handleInventoryMouseClick(int, int, int,
 * ClickType, Player) is the long-standing client-side entry point vanilla's
 * own screens use for every slot click; it is unrelated to the GUI
 * rendering rewrite but was not independently re-confirmed against 26.2
 * sources for this response.
 */
public final class TransferLogic {

	private TransferLogic() {
	}

	/** Player inventory -> container. Marked (BLUE) items only, or everything if none are marked. */
	public static void transferUp(AbstractContainerMenu menu, int containerId) {
		transfer(menu, containerId, SlotRanges.playerInventoryIndices(menu));
	}

	/** Container -> player inventory. Marked (BLUE) items only, or everything if none are marked. */
	public static void transferDown(AbstractContainerMenu menu, int containerId) {
		transfer(menu, containerId, SlotRanges.containerIndices(menu));
	}

	private static void transfer(AbstractContainerMenu menu, int containerId, List<Integer> sourceIndices) {
		LocalPlayer player = Minecraft.getInstance().player;
		if (player == null) return;

		Set<Integer> marked = SelectionManager.get().getMarked(menu, SelectionManager.Marker.CHEST);
		List<Integer> targets = marked.isEmpty()
				? sourceIndices
				: sourceIndices.stream().filter(marked::contains).toList();

		for (int slotIndex : targets) {
			Slot slot = menu.slots.get(slotIndex);
			if (!slot.hasItem()) continue;
			Minecraft.getInstance().gameMode.handleInventoryMouseClick(
					containerId, slotIndex, 0, ClickType.QUICK_MOVE, player);
		}
	}
}
