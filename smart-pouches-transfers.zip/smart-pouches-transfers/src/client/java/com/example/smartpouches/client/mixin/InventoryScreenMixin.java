package com.example.smartpouches.client.mixin;

import com.example.smartpouches.client.gui.IconButton;
import com.example.smartpouches.client.logic.BundleLogic;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.InventoryMenu;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Adds the 2 requested buttons - [pack inventory], [unpack inventory] - to
 * the player inventory screen, per spec "next to the vanilla recipe book".
 *
 * PLACEMENT NOTE: the recipe book toggle button's exact coordinates live on
 * a private/package field inside InventoryScreen (or its
 * EffectRenderingInventoryScreen superclass) that can only be read
 * reliably from decompiled 26.2 sources. Rather than guess a byte-fragile
 * accessor for it, this places the two buttons at a fixed offset above the
 * inventory panel (same convention as the chest buttons) so it degrades
 * gracefully. If you'd rather anchor tightly to the real recipe book
 * button, add an @Accessor for that field/widget once you have genSources
 * open and swap the two constants below for its real x/y.
 *
 * VERIFY: targets InventoryScreen#init() and assumes InventoryScreen still
 * extends (indirectly) AbstractContainerScreen<InventoryMenu> in 26.2, as
 * it has for many years; not independently re-confirmed against 26.2
 * sources for this response.
 */
@Mixin(InventoryScreen.class)
public abstract class InventoryScreenMixin extends AbstractContainerScreen<InventoryMenu> {

	private InventoryScreenMixin(InventoryMenu menu, Inventory playerInventory, Component title) {
		super(menu, playerInventory, title);
	}

	@Inject(method = "init", at = @At("TAIL"))
	private void smartpouches$addButtons(CallbackInfo ci) {
		AbstractContainerScreenAccessor accessor = (AbstractContainerScreenAccessor) this;
		int left = accessor.smartpouches$getLeftPos();
		int top = accessor.smartpouches$getTopPos();
		int imageWidth = accessor.smartpouches$getImageWidth();

		int size = 12;
		int spacing = 1;
		// Fixed offset placeholder - see PLACEMENT NOTE above.
		int startX = left + imageWidth - (size * 2 + spacing) - 6;
		int y = top - size - 2;

		InventoryMenu menu = this.getMenu();
		int containerId = menu.containerId;

		this.addRenderableWidget(new IconButton(startX, y, size, "\uD83E\uDDF3\u2191",
				Component.translatable("smartpouches.button.pack_inventory"),
				btn -> BundleLogic.packInventory(menu, containerId)));

		this.addRenderableWidget(new IconButton(startX + (size + spacing), y, size, "\uD83E\uDDF3\u2193",
				Component.translatable("smartpouches.button.unpack_inventory"),
				btn -> BundleLogic.unpackInventory(menu, containerId)));
	}
}
