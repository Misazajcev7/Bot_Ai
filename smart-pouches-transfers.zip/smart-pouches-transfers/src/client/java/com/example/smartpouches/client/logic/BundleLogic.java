package com.example.smartpouches.client.logic;

import com.example.smartpouches.client.selection.SelectionManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.MultiPlayerGameMode;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.BundleItem;

import java.util.List;
import java.util.Set;

/**
 * Handles the pack/unpack ([bag-up] / [bag-down]) buttons.
 *
 * Bundles don't have a "quick move merge" like ordinary stacking items -
 * loading/unloading one is a cursor-carry interaction: pick the bundle up
 * onto the cursor, then click item slots to load it (left-click, absorbs a
 * stack) or click an empty slot to unload it (right-click, ejects the most
 * recently added stack), then put the bundle back down. This mirrors that
 * exact interaction sequence via simulated clicks so the server sees normal,
 * legal container clicks rather than us mutating stacks directly.
 *
 * VERIFY: this depends on BundleItem's click-absorb/eject behaviour and on
 * PRIMARY (button 0) = "load", SECONDARY (button 1) = "eject one" being
 * routed through ClickType.PICKUP the same way it has been since bundles
 * were added. This is a good-faith best effort based on that established
 * mechanic; please sanity-check pack/unpack in-game before relying on it,
 * since it was not re-verified against 26.2 sources for this response.
 */
public final class BundleLogic {

	private BundleLogic() {
	}

	public static void packContainer(AbstractContainerMenu menu, int containerId) {
		pack(menu, containerId, SlotRanges.containerIndices(menu));
	}

	public static void packInventory(AbstractContainerMenu menu, int containerId) {
		pack(menu, containerId, SlotRanges.playerInventoryIndices(menu));
	}

	public static void unpackContainer(AbstractContainerMenu menu, int containerId) {
		unpack(menu, containerId, SlotRanges.containerIndices(menu));
	}

	public static void unpackInventory(AbstractContainerMenu menu, int containerId) {
		unpack(menu, containerId, SlotRanges.playerInventoryIndices(menu));
	}

	private static void pack(AbstractContainerMenu menu, int containerId, List<Integer> scope) {
		LocalPlayer player = Minecraft.getInstance().player;
		if (player == null) return;
		MultiPlayerGameMode gameMode = Minecraft.getInstance().gameMode;
		Set<Integer> marked = SelectionManager.get().getMarked(menu, SelectionManager.Marker.BUNDLE);
		if (marked.isEmpty()) return; // spec: pack operates on YELLOW-marked items

		for (int bundleIndex : scope) {
			Slot bundleSlot = menu.slots.get(bundleIndex);
			if (!bundleSlot.hasItem()) continue;
			if (!(bundleSlot.getItem().getItem() instanceof BundleItem)) continue;

			// Pick the bundle up onto the cursor.
			gameMode.handleInventoryMouseClick(containerId, bundleIndex, 0, ClickType.PICKUP, player);
			if (menu.getCarried().isEmpty()) continue; // pickup failed (e.g. cursor busy) - skip this bundle

			for (int itemIndex : scope) {
				if (itemIndex == bundleIndex || !marked.contains(itemIndex)) continue;
				Slot itemSlot = menu.slots.get(itemIndex);
				if (!itemSlot.hasItem() || itemSlot.getItem().getItem() instanceof BundleItem) continue;

				// Left-click a marked item slot while carrying the bundle: absorb into it.
				gameMode.handleInventoryMouseClick(containerId, itemIndex, 0, ClickType.PICKUP, player);
			}

			// Put the (now fuller) bundle back where it came from.
			gameMode.handleInventoryMouseClick(containerId, bundleIndex, 0, ClickType.PICKUP, player);
		}
	}

	private static void unpack(AbstractContainerMenu menu, int containerId, List<Integer> scope) {
		LocalPlayer player = Minecraft.getInstance().player;
		if (player == null) return;
		MultiPlayerGameMode gameMode = Minecraft.getInstance().gameMode;

		for (int bundleIndex : scope) {
			Slot bundleSlot = menu.slots.get(bundleIndex);
			if (!bundleSlot.hasItem()) continue;
			if (!(bundleSlot.getItem().getItem() instanceof BundleItem)) continue;

			gameMode.handleInventoryMouseClick(containerId, bundleIndex, 0, ClickType.PICKUP, player);
			if (menu.getCarried().isEmpty()) continue;

			// Eject one stack per free slot in scope until the bundle is
			// empty or we run out of free slots.
			for (int freeIndex : scope) {
				if (freeIndex == bundleIndex) continue;
				if (menu.getCarried().isEmpty()) break;
				Slot freeSlot = menu.slots.get(freeIndex);
				if (freeSlot.hasItem()) continue;

				// Right-click an empty slot while carrying the bundle: eject one stack.
				gameMode.handleInventoryMouseClick(containerId, freeIndex, 1, ClickType.PICKUP, player);
			}

			// Whatever is left in the bundle (if we ran out of free slots) goes back.
			gameMode.handleInventoryMouseClick(containerId, bundleIndex, 0, ClickType.PICKUP, player);
		}
	}
}
