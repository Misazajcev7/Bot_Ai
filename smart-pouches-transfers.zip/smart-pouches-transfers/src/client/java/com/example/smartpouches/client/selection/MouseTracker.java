package com.example.smartpouches.client.selection;

/**
 * Screen render callbacks hand us the current mouse position every frame;
 * we stash it here so key-press handlers (which don't receive a mouse
 * position) can ask "what's hovered right now?" without needing a
 * dedicated accessor mixin into Minecraft's mouse handler.
 */
public final class MouseTracker {
	private static double x;
	private static double y;

	private MouseTracker() {
	}

	public static void update(double mouseX, double mouseY) {
		x = mouseX;
		y = mouseY;
	}

	public static double x() {
		return x;
	}

	public static double y() {
		return y;
	}
}
