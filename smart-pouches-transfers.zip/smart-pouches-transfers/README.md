# Smart Pouches & Transfers

A Fabric client mod for Minecraft **26.2** adding cyclic BLUE/GOLD slot
markers, keybinds, and one-click GUI buttons for instant chest transfers and
bundle packing/unpacking.

## ⚠️ Before you build: read this

This mod targets Minecraft **26.2**, which shipped some very large, very
recent changes to the modding toolchain:

1. **Versioning moved to year.month** (26.1, 26.2, ...) instead of 1.2x.
2. **26.1 was the first fully de-obfuscated release** — the game ships with
   Mojang's own class/method names built in, and **Yarn mappings are no
   longer used or needed**. Every name in this project (`KeyMapping`,
   `AbstractContainerScreen`, `GuiGraphicsExtractor`, ...) is a Mojang name.
3. **The GUI render pipeline was rewritten.** `Screen.render(GuiGraphics, ...)`
   is gone; screens now implement `extractRenderState(GuiGraphicsExtractor, ...)`,
   and widgets implement `extractWidgetRenderState(...)` instead of
   `renderWidget(...)`. This is part of a state-extraction split ahead of the
   new optional Vulkan rendering backend.
4. Building requires **Java 25**, **Loom 1.17+**, and **Gradle 9.5.1+**.

Every API call in this project that I could check against Fabric's current
(26.2) documentation — key mappings, `GuiGraphicsExtractor` drawing calls,
`AbstractWidget`, `Screen#init`/`extractRenderState` — is confirmed against
that documentation. A handful of things are **not** independently
verifiable from documentation and only exist in the decompiled game jar;
those are marked `// VERIFY` in the source and listed below. None of them
are exotic — they're standard, long-lived vanilla names — but I can't
promise the exact spelling/signature without decompiling 26.2 myself, which
this environment can't do (no access to Mojang's asset/library servers).

### Verification checklist (5–10 minutes with Loom's generated sources)

Run `./gradlew genSources` (or use "Generate Sources" in your IDE) and check:

| File | What to check |
|---|---|
| `AbstractContainerScreenAccessor.java` | Field names `leftPos`, `topPos`, `imageWidth` on `AbstractContainerScreen` |
| `AbstractContainerScreenMixin.java` | `AbstractContainerScreen#extractRenderState` still has signature `(GuiGraphicsExtractor, int, int, float)` |
| `ChestScreenMixin.java` | `ChestScreen` still extends `AbstractContainerScreen<ChestMenu>` and has an `init()` method |
| `InventoryScreenMixin.java` | Same, for `InventoryScreen` / `InventoryMenu`; adjust the placement comment if you want to anchor to the real recipe book button |
| `TransferLogic.java` / `BundleLogic.java` | `MultiPlayerGameMode#handleInventoryMouseClick(int, int, int, ClickType, Player)` signature |
| `SlotRanges.java` | Slot ordering assumption (container slots first, then 36 player-inventory slots) still holds for the containers you care about |

If any of these have shifted, the fix is a one-line rename in the listed
file — nothing else in the project depends on them.

## What it does

- **BLUE marker** (top-left corner of a slot): item is queued for the
  instant chest transfer buttons.
- **GOLD marker** (bottom-right corner of a slot): item is queued for the
  bundle pack/unpack buttons.
- Clicking/pressing a marker toggle again removes it (cyclic on/off).

### Keybinds (all rebindable in Options > Controls > Key Binds)

| Default | Action |
|---|---|
| `J` | Select/deselect all eligible items in the open screen for **chest transfer** (BLUE) |
| `K` | Select/deselect all eligible items in the open screen for **bundle transfer** (GOLD) |
| Middle mouse click | Toggle BLUE marker on the hovered item |
| `G` | Toggle GOLD marker on the hovered item |

"Select all" skips non-stackable items (tools, armor, anything with a max
stack size of 1), per spec.

### Chest / container screen buttons (top-right)

- **🧳↑ Pack** — packs every GOLD-marked item in the container into bundles
  already sitting in that same container.
- **🧳↓ Unpack** — empties every bundle in the container into free slots in
  that same container.
- **↑ Transfer Up** — sends BLUE-marked items from your inventory into the
  container; sends *everything* if nothing is marked.
- **↓ Transfer Down** — sends BLUE-marked items from the container into your
  inventory; sends *everything* if nothing is marked.

### Player inventory screen buttons

- **🧳↑ Pack** / **🧳↓ Unpack** — same as above, scoped to your own inventory.

## Design notes

- **Transfers are simulated shift-clicks** (`ClickType.QUICK_MOVE`) rather
  than hand-rolled stack math, so stacking/overflow/capacity behave exactly
  like vanilla and stay correctly synced with the server.
- **Bundle packing/unpacking is simulated cursor-carry clicks** (pick the
  bundle up, click marked items to load it, click empty slots to unload it,
  put it back) — the same sequence a player's hand would perform. This
  depends on `BundleItem`'s click-absorb/eject behavior; please test it
  in-game before relying on it (see the `// VERIFY` note in `BundleLogic.java`).
- **Selection is scoped to the currently open menu instance** via a
  `WeakHashMap`, so marks naturally clear when you close the screen.
- Marker rendering and hover-detection are done independently in this mod
  (via `leftPos`/`topPos` + each `Slot`'s own `x`/`y`) rather than by reading
  vanilla's private "hovered slot" field, since that's a smaller, more
  stable surface to depend on.

## Project layout

```
src/main/java/...        - common entrypoint (this mod is entirely client-side)
src/client/java/...
  client/SmartPouchesTransfersClient.java   - keybinds + screen event wiring
  client/selection/       - marker state + mouse-position tracking
  client/logic/           - transfer & bundle pack/unpack logic
  client/gui/IconButton.java - the custom button widget
  client/mixin/           - button injection + marker rendering
```
